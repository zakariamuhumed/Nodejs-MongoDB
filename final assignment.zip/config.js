module.exports = {
    'secretKey': '12345-67890-09876-54321',
    'mongoUrl' : 'mongodb://localhost:27017/nucampsite',
    'facebook': {
        clientId: '614710682889095',
        clientSecret: '3ab54b2e967bbe28423d01f6b3081ee6'
    }

}